﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATMEntity
{
    public  class RetiroViewModel
    {
        [Required]
        [Range(100, int.MaxValue, ErrorMessage = "El monto debe ser un múltiplo de 100.")]
        public int Monto { get; set; }
    }
}
