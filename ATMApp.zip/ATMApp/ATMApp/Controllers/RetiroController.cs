﻿using ATMApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.IO;

namespace ATMApp.Controllers
{
    public class RetiroController : Controller
    {
        private readonly string filePath = "dispensacion_mode.txt"; // Ruta del archivo

        [HttpGet]
        public IActionResult Retiro()
        {
            return View(new RetiroViewModel());
        }

        [HttpPost]
        public IActionResult Retiro(RetiroViewModel model)
        {
            if (ModelState.IsValid)
            {
                var modo = ObtenerModoDispensacion();

                // Validar el monto según el modo de dispensación
                if (!EsMontoValido(model.Monto, modo))
                {
                    ModelState.AddModelError(string.Empty, $"Este cajero solo da papeletas de {modo}. Coloque un monto adecuado a eso.");
                    return View(model);
                }

                var resultado = ProcesarRetiro(model.Monto, modo);
                if (resultado != null)
                {
                    return View("Resultado", resultado);
                }
            }
            return View(model);
        }

        private bool EsMontoValido(int monto, string modo)
        {
            if (modo == "200 y 1000")
            {
                return monto % 200 == 0 || monto % 1000 == 0;
            }
            else if (modo == "100 y 500")
            {
                return monto % 100 == 0 || monto % 500 == 0;
            }
            else if (modo == "Eficiente")
            {
                return monto % 100 == 0;
            }
            return false;
        }

        private ResultadoViewModel ProcesarRetiro(int monto, string modo)
        {
            var resultado = new ResultadoViewModel { Monto = monto, Papeletas = new Dictionary<int, int>() };

            if (modo == "200 y 1000")
            {
                resultado = CalcularPapeletas(monto, new int[] { 1000, 200 });
            }
            else if (modo == "100 y 500")
            {
                resultado = CalcularPapeletas(monto, new int[] { 500, 100 });
            }
            else if (modo == "Eficiente")
            {
                resultado = CalcularPapeletas(monto, new int[] { 1000, 500, 200, 100 });
            }

            return resultado;
        }

        private ResultadoViewModel CalcularPapeletas(int monto, int[] denominaciones)
        {
            var resultado = new ResultadoViewModel { Monto = monto, Papeletas = new Dictionary<int, int>() };
            foreach (var denominacion in denominaciones)
            {
                while (monto >= denominacion)
                {
                    monto -= denominacion;
                    if (!resultado.Papeletas.ContainsKey(denominacion))
                    {
                        resultado.Papeletas[denominacion] = 0;
                    }
                    resultado.Papeletas[denominacion]++;
                }
            }
            return resultado;
        }

        private string ObtenerModoDispensacion()
        {
            if (System.IO.File.Exists(filePath))
            {
                return System.IO.File.ReadAllText(filePath);
            }
            return "Eficiente"; // Valor por defecto si no existe el archivo
        }
    }
}
