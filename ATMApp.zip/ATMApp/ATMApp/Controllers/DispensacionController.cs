﻿using ATMApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.IO;

namespace ATMApp.Controllers
{
    public class DispensacionController : Controller
    {
        private readonly string filePath = "dispensacion_mode.txt"; // Ruta del archivo

        [HttpGet]
        public IActionResult Configuracion()
        {
            var modo = ObtenerModoDispensacion() ?? "Eficiente";
            return View(new ConfiguracionViewModel { Modo = modo });
        }

        [HttpPost]
        public IActionResult Configuracion(ConfiguracionViewModel model)
        {
            if (ModelState.IsValid)
            {
                GuardarModoDispensacion(model.Modo);
                ViewBag.Mensaje = "Modo de dispensación guardado exitosamente.";
            }
            return View(model);
        }

        private void GuardarModoDispensacion(string modo)
        {
            System.IO.File.WriteAllText(filePath, modo);
        }

        private string ObtenerModoDispensacion()
        {
            if (System.IO.File.Exists(filePath))
            {
                return System.IO.File.ReadAllText(filePath);
            }
            return "Eficiente"; // Valor por defecto si no existe el archivo
        }
    }
}
