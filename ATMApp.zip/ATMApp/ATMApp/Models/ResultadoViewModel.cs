﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATMApp.Models
{
    public class ResultadoViewModel
    {
        public int Monto { get; set; }
        public Dictionary<int, int> Papeletas { get; set; }
    }
}
